import React from 'react';
import { Shield, Zap, Lock, Headphones, ArrowLeft, Target } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: Shield,
      title: '100% Real Users',
      description: 'All followers and engagement come from real, active accounts. No bots or fake profiles.',
      color: 'from-green-400 to-green-600'
    },
    {
      icon: Zap,
      title: 'Quick Results',
      description: 'See growth within 24-48 hours. Our proven methods deliver fast and reliable results.',
      color: 'from-yellow-400 to-orange-500'
    },
    {
      icon: Lock,
      title: 'Account Safety Guaranteed',
      description: 'Your account security is our priority. We never ask for passwords or compromise your account.',
      color: 'from-blue-400 to-blue-600'
    },
    {
      icon: Headphones,
      title: 'Round-the-Clock Support',
      description: 'Our expert team is available 24/7 to assist you with any questions or concerns.',
      color: 'from-purple-400 to-purple-600'
    },
    {
      icon: ArrowLeft,
      title: '100% Satisfaction Guaranteed',
      description: 'Not satisfied with results? We offer full refund within 30 days, no questions asked.',
      color: 'from-pink-400 to-pink-600'
    },
    {
      icon: Target,
      title: 'Personalized Approach',
      description: 'Tailored growth strategies based on your niche, audience, and specific goals.',
      color: 'from-teal-400 to-teal-600'
    }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-900/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Why Choose Our
            <span className="bg-gradient-to-r from-pink-500 to-teal-400 bg-clip-text text-transparent">
              {' '}Growth Services?
            </span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="p-8 rounded-2xl bg-gray-800/50 border border-gray-700 backdrop-blur-lg hover:border-gray-600 transition-all duration-300 group hover:scale-105"
            >
              <div className={`inline-flex p-4 rounded-full bg-gradient-to-r ${feature.color} mb-6 group-hover:scale-110 transition-transform`}>
                <feature.icon className="h-6 w-6 text-white" />
              </div>
              
              <h3 className="text-xl font-bold text-white mb-4">{feature.title}</h3>
              <p className="text-gray-300 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;