import React from 'react';
import { Package, User, TrendingUp } from 'lucide-react';

const HowItWorks = () => {
  const steps = [
    {
      icon: Package,
      title: 'Choose Your Package',
      description: 'Select the growth package that fits your needs and budget',
      color: 'from-pink-500 to-purple-600'
    },
    {
      icon: User,
      title: 'Provide Your Profile',
      description: 'Share your social media profile link (no password needed)',
      color: 'from-purple-500 to-blue-600'
    },
    {
      icon: TrendingUp,
      title: 'Watch Your Growth',
      description: 'Sit back and watch your followers, likes, and engagement soar',
      color: 'from-blue-500 to-teal-400'
    }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Get Growing in
            <span className="bg-gradient-to-r from-pink-500 to-teal-400 bg-clip-text text-transparent">
              {' '}3 Simple Steps
            </span>
          </h2>
        </div>

        <div className="relative">
          {/* Connecting line for desktop */}
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-teal-400 transform -translate-y-1/2 z-0"></div>

          <div className="grid md:grid-cols-3 gap-8 relative z-10">
            {steps.map((step, index) => (
              <div
                key={index}
                className="text-center group"
              >
                <div className={`inline-flex p-6 rounded-full bg-gradient-to-r ${step.color} mb-6 group-hover:scale-110 transition-transform shadow-2xl`}>
                  <step.icon className="h-12 w-12 text-white" />
                </div>
                
                <div className="bg-gray-800/50 p-6 rounded-2xl border border-gray-700 backdrop-blur-lg hover:border-gray-600 transition-all">
                  <div className={`text-2xl font-bold mb-2 bg-gradient-to-r ${step.color} bg-clip-text text-transparent`}>
                    Step {index + 1}
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-4">{step.title}</h3>
                  <p className="text-gray-300">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center mt-12">
          <button className="px-8 py-4 bg-gradient-to-r from-pink-500 to-teal-400 rounded-lg font-semibold text-lg hover:from-pink-600 hover:to-teal-500 transition-all transform hover:scale-105 shadow-lg">
            Get Started Today
          </button>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;