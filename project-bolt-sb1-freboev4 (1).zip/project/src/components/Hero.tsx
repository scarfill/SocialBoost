import React, { useEffect, useState } from 'react';
import { TrendingUp, Users, Heart, Clock } from 'lucide-react';

const AnimatedCounter = ({ target, prefix = '', suffix = '' }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const duration = 2000;
    const steps = 60;
    const increment = target / steps;
    let current = 0;

    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [target]);

  return <span>{prefix}{count.toLocaleString()}{suffix}</span>;
};

const Hero = () => {
  return (
    <section className="pt-20 pb-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-pink-500/10 via-purple-500/10 to-teal-400/10"></div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="bg-gradient-to-r from-pink-500 via-purple-500 to-teal-400 bg-clip-text text-transparent">
              Skyrocket Your
            </span>
            <br />
            <span className="text-white">Social Media Presence</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-300 mb-4 max-w-3xl mx-auto">
            Professional TikTok, Instagram & Facebook Growth Services
          </p>
          
          <p className="text-lg text-gray-400 mb-12 max-w-2xl mx-auto">
            Get real followers, massive views, and authentic engagement. Boost your social media accounts with our proven growth strategies.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <button className="px-8 py-4 bg-gradient-to-r from-pink-500 to-teal-400 rounded-lg font-semibold text-lg hover:from-pink-600 hover:to-teal-500 transition-all transform hover:scale-105 shadow-lg">
              Start Growing Now
            </button>
            <button className="px-8 py-4 border-2 border-gray-600 rounded-lg font-semibold text-lg hover:border-gray-400 transition-all">
              View Our Packages
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="flex justify-center mb-2">
                <Users className="h-8 w-8 text-pink-500" />
              </div>
              <div className="text-3xl font-bold text-white mb-1">
                <AnimatedCounter target={2000000} suffix="+" />
              </div>
              <div className="text-gray-400">Followers Delivered</div>
            </div>
            
            <div className="text-center">
              <div className="flex justify-center mb-2">
                <TrendingUp className="h-8 w-8 text-purple-500" />
              </div>
              <div className="text-3xl font-bold text-white mb-1">
                <AnimatedCounter target={500000} suffix="+" />
              </div>
              <div className="text-gray-400">Accounts Boosted</div>
            </div>
            
            <div className="text-center">
              <div className="flex justify-center mb-2">
                <Heart className="h-8 w-8 text-red-500" />
              </div>
              <div className="text-3xl font-bold text-white mb-1">
                <AnimatedCounter target={98} suffix="%" />
              </div>
              <div className="text-gray-400">Success Rate</div>
            </div>
            
            <div className="text-center">
              <div className="flex justify-center mb-2">
                <Clock className="h-8 w-8 text-teal-400" />
              </div>
              <div className="text-3xl font-bold text-white mb-1">24/7</div>
              <div className="text-gray-400">Customer Support</div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating icons animation */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 animate-bounce">
          <div className="w-8 h-8 bg-pink-500/20 rounded-full flex items-center justify-center">
            <Heart className="w-4 h-4 text-pink-500" />
          </div>
        </div>
        <div className="absolute top-32 right-16 animate-bounce delay-1000">
          <div className="w-10 h-10 bg-purple-500/20 rounded-full flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-purple-500" />
          </div>
        </div>
        <div className="absolute bottom-40 left-20 animate-bounce delay-2000">
          <div className="w-6 h-6 bg-teal-400/20 rounded-full flex items-center justify-center">
            <Users className="w-3 h-3 text-teal-400" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;