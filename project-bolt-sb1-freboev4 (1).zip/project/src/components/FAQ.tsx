import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(null);

  const faqs = [
    {
      question: 'Is it safe for my account?',
      answer: 'Absolutely! We use completely safe, organic methods that comply with all platform guidelines. We never require your password and all growth is generated through legitimate means.'
    },
    {
      question: 'How quickly will I see results?',
      answer: 'Most clients see initial results within 24-48 hours, with significant growth visible within 7 days. Our premium packages offer even faster delivery times.'
    },
    {
      question: 'Do you need my password?',
      answer: 'Never! We only need your profile URL or username. Our methods work externally and never require access to your account credentials.'
    },
    {
      question: 'Are the followers real people?',
      answer: 'Yes, 100%! All followers come from real, active accounts. We have a strict no-bot policy and guarantee authentic engagement from genuine users.'
    },
    {
      question: 'What if I\'m not satisfied?',
      answer: 'We offer a 30-day money-back guarantee. If you\'re not completely satisfied with your results, we\'ll provide a full refund, no questions asked.'
    },
    {
      question: 'Do you offer refunds?',
      answer: 'Yes, we have a comprehensive refund policy. If our service doesn\'t meet your expectations within the first 30 days, you\'re eligible for a complete refund.'
    },
    {
      question: 'Can I track my progress?',
      answer: 'Absolutely! We provide detailed analytics reports and real-time tracking so you can monitor your growth progress every step of the way.'
    },
    {
      question: 'Do you work with business accounts?',
      answer: 'Yes! We work with all account types including personal profiles, business accounts, creator accounts, and verified accounts across all platforms.'
    }
  ];

  const toggleFAQ = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-900/30">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Frequently Asked
            <span className="bg-gradient-to-r from-pink-500 to-teal-400 bg-clip-text text-transparent">
              {' '}Questions
            </span>
          </h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-gray-800/50 border border-gray-700 rounded-2xl backdrop-blur-lg transition-all hover:border-gray-600"
            >
              <button
                className="w-full px-8 py-6 text-left flex items-center justify-between focus:outline-none"
                onClick={() => toggleFAQ(index)}
              >
                <h3 className="text-lg font-semibold text-white pr-4">{faq.question}</h3>
                <div className="flex-shrink-0">
                  {openIndex === index ? (
                    <ChevronUp className="w-6 h-6 text-pink-500" />
                  ) : (
                    <ChevronDown className="w-6 h-6 text-gray-400" />
                  )}
                </div>
              </button>
              
              {openIndex === index && (
                <div className="px-8 pb-6 pt-2">
                  <p className="text-gray-300 leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;