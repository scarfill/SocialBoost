import React from 'react';
import { Star, TrendingUp } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Sarah Johnson',
      platform: 'TikTok',
      beforeFollowers: '2.3K',
      afterFollowers: '47.8K',
      growth: '+1,980%',
      quote: 'SocialBoost transformed my TikTok presence completely! I went from struggling to get views to having multiple viral videos. The growth was organic and sustained.',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      platformColor: 'from-red-500 to-pink-600'
    },
    {
      name: 'Marcus Rodriguez',
      platform: 'Instagram',
      beforeFollowers: '1.2K',
      afterFollowers: '28.5K',
      growth: '+2,275%',
      quote: 'As a fitness influencer, getting authentic engagement was crucial. SocialBoost delivered real followers who actually engage with my content. My brand partnerships tripled!',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      platformColor: 'from-purple-500 to-pink-500'
    },
    {
      name: 'Emily Chen',
      platform: 'Facebook',
      beforeFollowers: '890',
      afterFollowers: '15.2K',
      growth: '+1,607%',
      quote: 'My local bakery business exploded after using SocialBoost! The increased page likes translated directly to more customers walking through my door.',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      platformColor: 'from-blue-500 to-blue-600'
    }
  ];

  return (
    <section id="results" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-900/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Real Results from
            <span className="bg-gradient-to-r from-pink-500 to-teal-400 bg-clip-text text-transparent">
              {' '}Real Clients
            </span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="p-8 rounded-2xl bg-gray-800/50 border border-gray-700 backdrop-blur-lg hover:border-gray-600 transition-all duration-300 hover:scale-105"
            >
              <div className="flex items-center mb-6">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className="w-16 h-16 rounded-full mr-4 object-cover"
                />
                <div>
                  <h3 className="text-lg font-semibold text-white">{testimonial.name}</h3>
                  <div className={`inline-block px-3 py-1 rounded-full text-xs font-semibold bg-gradient-to-r ${testimonial.platformColor} text-white`}>
                    {testimonial.platform}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6 p-4 bg-gray-700/50 rounded-lg">
                <div className="text-center">
                  <div className="text-sm text-gray-400 mb-1">Before</div>
                  <div className="text-lg font-semibold text-white">{testimonial.beforeFollowers}</div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-gray-400 mb-1">After</div>
                  <div className="text-lg font-semibold text-white">{testimonial.afterFollowers}</div>
                </div>
                <div className="col-span-2 text-center mt-2">
                  <div className="flex items-center justify-center space-x-2">
                    <TrendingUp className="w-4 h-4 text-green-400" />
                    <span className="text-green-400 font-bold">{testimonial.growth} Growth</span>
                  </div>
                </div>
              </div>

              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>

              <p className="text-gray-300 italic">"{testimonial.quote}"</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;