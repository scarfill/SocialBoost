import React from 'react';
import { MessageCircle, Mail, Phone, Clock } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-900/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            24/7 Customer
            <span className="bg-gradient-to-r from-pink-500 to-teal-400 bg-clip-text text-transparent">
              {' '}Support
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            We respond within 15 minutes. Get instant help with our multiple support channels.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <div className="text-center p-6 rounded-2xl bg-gray-800/50 border border-gray-700 backdrop-blur-lg hover:border-gray-600 transition-all group">
            <div className="inline-flex p-4 rounded-full bg-gradient-to-r from-green-400 to-green-600 mb-4 group-hover:scale-110 transition-transform">
              <MessageCircle className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Live Chat</h3>
            <p className="text-gray-400 text-sm">Instant support available</p>
          </div>

          <div className="text-center p-6 rounded-2xl bg-gray-800/50 border border-gray-700 backdrop-blur-lg hover:border-gray-600 transition-all group">
            <div className="inline-flex p-4 rounded-full bg-gradient-to-r from-blue-400 to-blue-600 mb-4 group-hover:scale-110 transition-transform">
              <Mail className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Email Support</h3>
            <p className="text-gray-400 text-sm">support@socialboost.com</p>
          </div>

          <div className="text-center p-6 rounded-2xl bg-gray-800/50 border border-gray-700 backdrop-blur-lg hover:border-gray-600 transition-all group">
            <div className="inline-flex p-4 rounded-full bg-gradient-to-r from-green-500 to-green-700 mb-4 group-hover:scale-110 transition-transform">
              <Phone className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">WhatsApp</h3>
            <p className="text-gray-400 text-sm">Direct messaging</p>
          </div>

          <div className="text-center p-6 rounded-2xl bg-gray-800/50 border border-gray-700 backdrop-blur-lg hover:border-gray-600 transition-all group">
            <div className="inline-flex p-4 rounded-full bg-gradient-to-r from-purple-400 to-purple-600 mb-4 group-hover:scale-110 transition-transform">
              <Clock className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Response Time</h3>
            <p className="text-gray-400 text-sm">Within 15 minutes</p>
          </div>
        </div>

        <div className="max-w-2xl mx-auto">
          <div className="bg-gray-800/50 border border-gray-700 rounded-2xl p-8 backdrop-blur-lg">
            <h3 className="text-2xl font-bold text-white mb-6 text-center">Send us a message</h3>
            
            <form className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Name</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent text-white placeholder-gray-400"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
                  <input
                    type="email"
                    className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent text-white placeholder-gray-400"
                    placeholder="your@email.com"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Subject</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent text-white placeholder-gray-400"
                  placeholder="How can we help?"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Message</label>
                <textarea
                  rows="4"
                  className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent text-white placeholder-gray-400 resize-none"
                  placeholder="Tell us about your needs..."
                ></textarea>
              </div>
              
              <button
                type="submit"
                className="w-full py-4 bg-gradient-to-r from-pink-500 to-teal-400 rounded-lg font-semibold text-lg hover:from-pink-600 hover:to-teal-500 transition-all transform hover:scale-105"
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;