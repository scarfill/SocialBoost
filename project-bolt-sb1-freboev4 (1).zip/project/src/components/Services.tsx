import React from 'react';
import { TrendingUp, Heart, Share2, Video, MessageCircle, BarChart3 } from 'lucide-react';

const Services = () => {
  const services = [
    {
      platform: 'TikTok',
      color: 'from-red-500 to-pink-600',
      bgColor: 'bg-red-500/10',
      borderColor: 'border-red-500/30',
      icon: Video,
      services: [
        'Real TikTok Followers',
        'Video Views Boost',
        'Likes & Hearts',
        'Comments & Shares',
        'For You Page Optimization',
        'Viral Content Strategy'
      ],
      price: 'From $5',
      cta: 'Boost TikTok Account'
    },
    {
      platform: 'Instagram',
      color: 'from-purple-500 to-pink-500',
      bgColor: 'bg-purple-500/10',
      borderColor: 'border-purple-500/30',
      icon: Heart,
      services: [
        'Real Instagram Followers',
        'Post Likes & Views',
        'Story Views',
        'Reels Engagement',
        'Comments Boost',
        'Profile Optimization'
      ],
      price: 'From $3',
      cta: 'Grow Instagram'
    },
    {
      platform: 'Facebook',
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-500/10',
      borderColor: 'border-blue-500/30',
      icon: Share2,
      services: [
        'Facebook Page Likes',
        'Post Engagement',
        'Video Views',
        'Shares & Comments',
        'Group Member Growth',
        'Business Page Boost'
      ],
      price: 'From $4',
      cta: 'Expand Facebook Reach'
    }
  ];

  return (
    <section id="services" className="py-20 px-4 sm:px-6 lg:px-8 relative">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Choose Your Platform -
            <span className="bg-gradient-to-r from-pink-500 to-teal-400 bg-clip-text text-transparent">
              {' '}We'll Handle the Growth
            </span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className={`relative p-8 rounded-2xl ${service.bgColor} ${service.borderColor} border backdrop-blur-lg hover:scale-105 transition-all duration-300 group`}
            >
              <div className="text-center mb-8">
                <div className={`inline-flex p-4 rounded-full bg-gradient-to-r ${service.color} mb-4`}>
                  <service.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">{service.platform} Growth</h3>
              </div>

              <div className="space-y-3 mb-8">
                {service.services.map((item, idx) => (
                  <div key={idx} className="flex items-center space-x-3">
                    <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${service.color}`}></div>
                    <span className="text-gray-300">{item}</span>
                  </div>
                ))}
              </div>

              <div className="text-center">
                <div className="text-3xl font-bold text-white mb-4">{service.price}</div>
                <button className={`w-full py-3 px-6 bg-gradient-to-r ${service.color} rounded-lg font-semibold hover:opacity-90 transition-all transform group-hover:scale-105`}>
                  {service.cta}
                </button>
              </div>

              <div className="absolute -top-2 -right-2">
                <div className={`w-6 h-6 rounded-full bg-gradient-to-r ${service.color} animate-pulse`}></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;