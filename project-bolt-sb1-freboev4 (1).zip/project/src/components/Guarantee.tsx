import React from 'react';
import { Shield, DollarSign, Clock, TrendingUp } from 'lucide-react';

const Guarantee = () => {
  const guarantees = [
    {
      icon: DollarSign,
      title: 'Money-Back Guarantee',
      description: '30-day full refund policy',
      color: 'from-green-400 to-green-600'
    },
    {
      icon: Shield,
      title: 'Quality Assurance',
      description: '100% real users guaranteed',
      color: 'from-blue-400 to-blue-600'
    },
    {
      icon: Clock,
      title: 'Support Guarantee',
      description: '24/7 customer service',
      color: 'from-purple-400 to-purple-600'
    },
    {
      icon: TrendingUp,
      title: 'Growth Guarantee',
      description: 'Visible results within 48 hours',
      color: 'from-pink-400 to-pink-600'
    }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Our Promise to
            <span className="bg-gradient-to-r from-pink-500 to-teal-400 bg-clip-text text-transparent">
              {' '}You
            </span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {guarantees.map((guarantee, index) => (
            <div
              key={index}
              className="text-center p-8 rounded-2xl bg-gray-800/50 border border-gray-700 backdrop-blur-lg hover:border-gray-600 transition-all duration-300 hover:scale-105 group"
            >
              <div className={`inline-flex p-4 rounded-full bg-gradient-to-r ${guarantee.color} mb-6 group-hover:scale-110 transition-transform`}>
                <guarantee.icon className="h-8 w-8 text-white" />
              </div>
              
              <h3 className="text-xl font-bold text-white mb-4">{guarantee.title}</h3>
              <p className="text-gray-300">{guarantee.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <div className="inline-block p-8 rounded-2xl bg-gradient-to-r from-pink-500/20 to-teal-400/20 border border-pink-500/30 backdrop-blur-lg">
            <h3 className="text-2xl font-bold text-white mb-4">Ready to Start Growing?</h3>
            <p className="text-gray-300 mb-6">Join thousands of satisfied customers who have transformed their social media presence</p>
            <button className="px-8 py-4 bg-gradient-to-r from-pink-500 to-teal-400 rounded-lg font-semibold text-lg hover:from-pink-600 hover:to-teal-500 transition-all transform hover:scale-105 shadow-lg">
              Choose Your Package Now
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Guarantee;