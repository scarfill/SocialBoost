import React, { useState } from 'react';
import { Check, Star, Zap } from 'lucide-react';

const Pricing = () => {
  const [selectedPlatform, setSelectedPlatform] = useState('TikTok');

  const platforms = ['TikTok', 'Instagram', 'Facebook'];

  const packages = {
    TikTok: [
      {
        name: 'Starter Package',
        price: 5,
        popular: false,
        badge: 'Save 70%',
        delivery: '48-hour Delivery',
        features: [
          '1,000 Real TikTok Followers',
          '10,000 Video Views',
          '500 Likes',
          'Basic Analytics Report',
          '48-hour Delivery'
        ]
      },
      {
        name: 'Growth Package',
        price: 15,
        popular: true,
        badge: 'MOST POPULAR',
        delivery: '24-hour Delivery',
        features: [
          '5,000 Real TikTok Followers',
          '50,000 Video Views',
          '2,500 Likes',
          '100 Comments',
          'Advanced Analytics',
          '24-hour Delivery'
        ]
      },
      {
        name: 'Viral Package',
        price: 35,
        popular: false,
        badge: 'Premium',
        delivery: '12-hour Delivery',
        features: [
          '15,000 Real TikTok Followers',
          '200,000 Video Views',
          '10,000 Likes',
          '500 Comments',
          'Premium Strategy Session',
          'Priority Support',
          '12-hour Delivery'
        ]
      }
    ],
    Instagram: [
      {
        name: 'Basic Growth',
        price: 3,
        popular: false,
        badge: 'Best Value',
        delivery: '72-hour Delivery',
        features: [
          '500 Real Instagram Followers',
          '5,000 Post Likes',
          '1,000 Story Views',
          'Basic Support',
          '72-hour Delivery'
        ]
      },
      {
        name: 'Pro Growth',
        price: 12,
        popular: true,
        badge: 'MOST POPULAR',
        delivery: '48-hour Delivery',
        features: [
          '3,000 Real Instagram Followers',
          '25,000 Post Likes',
          '10,000 Story Views',
          '100 Comments',
          'Hashtag Strategy',
          '48-hour Delivery'
        ]
      },
      {
        name: 'Celebrity Package',
        price: 30,
        popular: false,
        badge: 'Premium',
        delivery: '24-hour Delivery',
        features: [
          '10,000 Real Instagram Followers',
          '100,000 Post Likes',
          '50,000 Story Views',
          '1,000 Comments',
          'Content Strategy Guide',
          'Priority Support',
          '24-hour Delivery'
        ]
      }
    ],
    Facebook: [
      {
        name: 'Page Boost',
        price: 4,
        popular: false,
        badge: 'Starter',
        delivery: '48-hour Delivery',
        features: [
          '1,000 Facebook Page Likes',
          '5,000 Post Engagements',
          '50 Comments',
          'Basic Analytics',
          '48-hour Delivery'
        ]
      },
      {
        name: 'Business Growth',
        price: 16,
        popular: true,
        badge: 'MOST POPULAR',
        delivery: '24-hour Delivery',
        features: [
          '5,000 Facebook Page Likes',
          '25,000 Post Engagements',
          '500 Shares',
          '200 Comments',
          'Business Strategy Session',
          '24-hour Delivery'
        ]
      },
      {
        name: 'Enterprise',
        price: 40,
        popular: false,
        badge: 'Premium',
        delivery: '12-hour Delivery',
        features: [
          '15,000 Facebook Page Likes',
          '100,000 Post Engagements',
          '2,000 Shares',
          '1,000 Comments',
          'Dedicated Account Manager',
          'Custom Strategy',
          '12-hour Delivery'
        ]
      }
    ]
  };

  const getPlatformColor = (platform) => {
    switch (platform) {
      case 'TikTok': return 'from-red-500 to-pink-600';
      case 'Instagram': return 'from-purple-500 to-pink-500';
      case 'Facebook': return 'from-blue-500 to-blue-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  return (
    <section id="packages" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Choose Your
            <span className="bg-gradient-to-r from-pink-500 to-teal-400 bg-clip-text text-transparent">
              {' '}Growth Package
            </span>
          </h2>
        </div>

        {/* Platform Selector */}
        <div className="flex justify-center mb-12">
          <div className="flex bg-gray-800 rounded-lg p-1">
            {platforms.map((platform) => (
              <button
                key={platform}
                onClick={() => setSelectedPlatform(platform)}
                className={`px-6 py-3 rounded-md font-semibold transition-all ${
                  selectedPlatform === platform
                    ? `bg-gradient-to-r ${getPlatformColor(platform)} text-white`
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {platform}
              </button>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {packages[selectedPlatform].map((pkg, index) => (
            <div
              key={index}
              className={`relative p-8 rounded-2xl backdrop-blur-lg transition-all duration-300 hover:scale-105 ${
                pkg.popular
                  ? 'bg-gradient-to-b from-gray-700/50 to-gray-800/50 border-2 border-pink-500 ring-2 ring-pink-500/20'
                  : 'bg-gray-800/50 border border-gray-700 hover:border-gray-600'
              }`}
            >
              {pkg.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-4 py-2 rounded-full text-sm font-semibold flex items-center space-x-2">
                    <Star className="w-4 h-4" />
                    <span>{pkg.badge}</span>
                  </div>
                </div>
              )}

              {!pkg.popular && (
                <div className="absolute -top-2 -right-2">
                  <div className="bg-gradient-to-r from-orange-400 to-orange-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
                    {pkg.badge}
                  </div>
                </div>
              )}

              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-white mb-4">{pkg.name}</h3>
                <div className="text-5xl font-bold text-white mb-2">
                  ${pkg.price}
                </div>
                <div className="text-gray-400 mb-4">{pkg.delivery}</div>
              </div>

              <div className="space-y-4 mb-8">
                {pkg.features.map((feature, idx) => (
                  <div key={idx} className="flex items-center space-x-3">
                    <div className="flex-shrink-0">
                      <Check className="w-5 h-5 text-green-400" />
                    </div>
                    <span className="text-gray-300">{feature}</span>
                  </div>
                ))}
              </div>

              <button className={`w-full py-4 px-6 rounded-lg font-semibold transition-all transform hover:scale-105 ${
                pkg.popular
                  ? `bg-gradient-to-r ${getPlatformColor(selectedPlatform)} text-white`
                  : 'bg-gray-700 hover:bg-gray-600 text-white'
              }`}>
                Order Package
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;