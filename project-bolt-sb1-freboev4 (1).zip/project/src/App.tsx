import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import Features from './components/Features';
import Pricing from './components/Pricing';
import Testimonials from './components/Testimonials';
import HowItWorks from './components/HowItWorks';
import FAQ from './components/FAQ';
import Guarantee from './components/Guarantee';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-white overflow-x-hidden">
      <Header />
      <Hero />
      <Services />
      <Features />
      <Pricing />
      <Testimonials />
      <HowItWorks />
      <FAQ />
      <Guarantee />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;